<?php declare(strict_types=1);
header('HTTP/1.0 404 Not Found');
