Read Me First
=============

Please make sure that you download the XOOPS Icon Set, and upload it to uploads/images directory
Read the table in admin help for the accurate description of the functionality of this module

Using the new class xoopsrequest.php

Version of xoops
----------------
ModuleBuilder is a module that create other basic modules for CMS Xoops.

Tested with xoops 2.5.7, you can not use it with earlier versions, unless because you do not fit some core files in the background and after some tests.

Now that is ahead xoops versions, and goes to 2.6.0, you should download xoops 2.5.7 and use with this latest version.

Therefore recommended not to use ModuleBuilder 1.91, with previous versions, to xoops 2.5.7
